package package2;
import package1.*;
 class Class2 {

	public static void main(String[] args) {
		
	      Class1 obj = new Class1();
				
				obj.display();

	}

}
