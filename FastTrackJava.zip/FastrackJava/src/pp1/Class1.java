package pp1;

 class Class1 {
	
	void display()
	{
	System.out.println("Hello");
	}

}
