package pack2;
import pack1.*;
 class Class2 {

	public static void main(String[] args) {
		Class1 c1=new Class1();
		c1.display();


	}

}
