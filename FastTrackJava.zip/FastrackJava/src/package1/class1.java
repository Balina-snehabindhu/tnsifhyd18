package package1;

   class class1 {
	
	private void display()
	{
	System.out.println("TNS");
	}
   }
   
