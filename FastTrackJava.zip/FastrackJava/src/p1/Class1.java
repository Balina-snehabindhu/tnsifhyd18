package p1;

public class Class1 {
	
	protected void display()
	{
	System.out.println("TNS Sessions");
	}
	}
