package pack1;
 public class Class1 {
	public void display()
	{
		System.out.println("display");
	}

}
