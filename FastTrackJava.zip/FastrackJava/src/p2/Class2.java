package p2;
import p1.*;
public class Class2 extends Class1{
	public static void main(String[] args) {
		Class2 obj=new Class2();
		obj.display();
	
	}


}
